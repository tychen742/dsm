OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> square(1) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> square(0) == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> square(2.5) == 6.25\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
